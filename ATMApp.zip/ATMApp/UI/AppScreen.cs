﻿using ATMApp.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ATMApp.UI
{
    public class AppScreen
    {
        internal const string cur = "RON ";
        internal static void Welcome()
        {
            Console.Clear();
            Console.Title = "Aplicatie Bancara"; //numele ferestrei
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n---------------Bun Venit!---------------");


            Utility.PressEnterToContinue();

            
        }

        internal static UserAccount UserLoginForm()
        {
            UserAccount tempUserAccount = new UserAccount();

            tempUserAccount.CardNumber = Validator.Convert<long>("numarul cardului dumneavoastra.");
            tempUserAccount.CardPin = Convert.ToInt32(Utility.GetSecretInput("Introduceti PIN-ul:"));
            return tempUserAccount;
        }

        internal static void LoginProgress()
        {
            Console.WriteLine("\nSe verfica numarul cardului si PIN-ul...");
            Utility.PrintDotAnimation();
        }

        internal static void PrintLockScreen()
        {
            Console.Clear();
            Utility.PrintMessage("Cont blocat. Va rugam mergeti pana la cea mai apropiata banca pentru a va debloca contul. Multumim.", true);
            Utility.PressEnterToContinue();
            Environment.Exit(1);
        }

        internal static void WelcomeCustomer(string fullName)
        {
            Console.WriteLine($"Bine ati revenit, {fullName}");
            Utility.PressEnterToContinue();
        }

        internal static void DisplayAppMenu()
        {
            Console.Clear();
            Console.WriteLine("-------------Meniu-------------");
            Console.WriteLine(":                      :");
            Console.WriteLine("1.Soldul contului      :");
            Console.WriteLine("2.Adaugati bani        :");
            Console.WriteLine("3.Retrageti bani       :");
            Console.WriteLine("4.Transfer             :");
            Console.WriteLine("5.Tranzactii           :");
            Console.WriteLine("6.Deconectare          :");
        }

        internal static void LogOutProgress()
        {
            Console.WriteLine("Va multumim ca ati folosit aplicatia bancara.");
            Utility.PrintDotAnimation();
            Console.Clear();
        }

        internal static int SelectAmount()
        {
            Console.WriteLine("");
            Console.WriteLine(":1.5 {0}         5.150 {0}", cur);
            Console.WriteLine(":2.10 {0}        6.200 {0}", cur);
            Console.WriteLine(":3.50 {0}        7.300 {0}", cur);
            Console.WriteLine(":4.100 {0}       8.500 {0}", cur);
            Console.WriteLine(":0.Alta");
            Console.WriteLine("");

            int selectedAmount = Validator.Convert<int>("optiunea:");
            switch (selectedAmount)
            {
                case 1:
                    return 5;
                    break;
                case 2:
                    return 10;
                    break;
                case 3:
                    return 50;
                    break;
                case 4:
                    return 100;
                    break;
                case 5:
                    return 150;
                    break;
                case 6:
                    return 200;
                    break;
                case 7:
                    return 300;
                    break;
                case 8:
                    return 500;
                    break;
                case 0:
                    return 0;
                    break;
                default:
                    Utility.PrintMessage("Comanda invalida. Incercati din nou.", false);
                    return -1;
                    break;
            }
            
        }
        internal InternalTransfer InternalTransferForm()
        {
            var internalTransfer = new InternalTransfer();
            internalTransfer.RecipientBankAccountNumber = Validator.Convert<long>("numarul contului destinatarului:");
            internalTransfer.TransferAmount = Validator.Convert<decimal>($"suma {cur}");
            internalTransfer.RecipientBankAccountName = Utility.GetUserImput("numele destinatarului:");
            return internalTransfer;
        }
    }
}
