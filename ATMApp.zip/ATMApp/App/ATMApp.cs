﻿using ATMApp.Domain.Entities;
using ATMApp.Domain.Enums;
using ATMApp.Domain.Interfaces;
using ATMApp.UI;
using ConsoleTables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace ATMApp
{
    public class ATMApp : IUserLogin, IUserAccountActions, ITransaction
    {
        private List<UserAccount> userAccountList;
        private UserAccount selectedAccount;
        private List<Transaction> _listOfTransactions;
        private const decimal minimumKeptAmount = 5;
        private readonly AppScreen screen;

        public ATMApp()
        {
            screen = new AppScreen();
        }

        public void Run()
        {
            AppScreen.Welcome();
            CheckUserCardNumberAndPassword();
            AppScreen.WelcomeCustomer(selectedAccount.FullName);
            while (true) 
            { 
            AppScreen.DisplayAppMenu();
            ProcessMenuoption();
            }
        }
        public void InitializeData()
        {
            userAccountList = new List<UserAccount>
            {
                new UserAccount{Id=1, FullName="Mihaela Costache", AccountNumber=123456789, CardNumber=123456789, CardPin=1234, AccountBalance=5000.00m, isLocked=false},
                new UserAccount{ Id = 2, FullName = "Elena Stefanescu", AccountNumber = 987654321, CardNumber = 987654321, CardPin = 4321, AccountBalance = 2040.00m, isLocked = false },
                new UserAccount{ Id = 3, FullName = "Iustin Popa", AccountNumber = 214356674, CardNumber = 234234345, CardPin = 3456, AccountBalance = 6000.00m, isLocked = true },
            };

            _listOfTransactions = new List<Transaction>();
        }

        public void CheckUserCardNumberAndPassword()
        {
            bool isCorrectLogin = false;
            while (isCorrectLogin == false)
            {
                UserAccount inputAccount = AppScreen.UserLoginForm();
                AppScreen.LoginProgress();
                foreach(UserAccount account in userAccountList)
                {
                    selectedAccount = account;
                    if (inputAccount.CardNumber.Equals(selectedAccount.CardNumber))
                    {
                        selectedAccount.TotalLogin++;

                        if (inputAccount.CardPin.Equals(selectedAccount.CardPin))
                        {
                            selectedAccount = account;

                            if(selectedAccount.isLocked || selectedAccount.TotalLogin>3)
                            {
                                AppScreen.PrintLockScreen();
                            }
                            else
                            {
                                selectedAccount.TotalLogin = 0;
                                isCorrectLogin = true;
                                break;
                            }
                        }
                    }

                    if (isCorrectLogin == false)
                    {
                        Utility.PrintMessage("\nNumarul cardului sau PIN-ul este invalid.", false);
                        selectedAccount.isLocked = selectedAccount.TotalLogin == 3;
                        if (selectedAccount.isLocked)
                        {
                            AppScreen.PrintLockScreen();
                        }
                    }
                    Console.Clear();
                }
            }

        }

        private void ProcessMenuoption()
        {
            switch(Validator.Convert<int>("o optiune: "))
            {
                case (int)AppMenu.CheckBalance:
                    CheckBalance();
                    break;
                case (int)AppMenu.PlaceDeposit:
                    PlaceDeposit();
                    break;
                case (int)AppMenu.MakeWithdrawal:
                    MakeWithdrawal();
                    break;
                case (int)AppMenu.InternalTransfer:
                    var internalTransfer = screen.InternalTransferForm();
                    ProcessInternalTransfer(internalTransfer);
                    break;
                case (int)AppMenu.ViewTransaction:
                    ViewTransaction();
                    break;
                case (int)AppMenu.Logout:
                    AppScreen.LogOutProgress();
                    Utility.PrintMessage("V-ati deconectat cu succes. Va multumim.");
                    Run();
                    break;
                default:
                    Utility.PrintMessage("Optiune invalida.", false);
                    break;
            }
        }

        public void CheckBalance()
        {
            Utility.PrintMessage($"Soldul dumneavoastra este: {Utility.FormatAmount(selectedAccount.AccountBalance)}");
        }

        public void PlaceDeposit()
        {
            Console.WriteLine("\nSunt permise doar sume multiple de 5 si 10.\n");
            var transation_amt = Validator.Convert<int>($"suma {AppScreen.cur}");

            Console.WriteLine("\nVerificam si numaram bancnotele.");
            Utility.PrintDotAnimation();
            Console.WriteLine(" ");

            if(transation_amt<=0)
            {
                Utility.PrintMessage("Suma trebuie sa fie mai mare decat 0. Incercati din nou.");
                return;
            }
            if(transation_amt %5!=0)
            {
                Utility.PrintMessage($"Introduceti sume in multipli de 5 sau 10. Incercati din nou.");
                return;
            }

            if(PreviewBanknotesCount(transation_amt)==false)
            {
                Utility.PrintMessage($"Ati anulat actiunea.", false);
                return;
            }

            InsertTransaction(selectedAccount.Id, TransactionType.Deposit, transation_amt, "");

            selectedAccount.AccountBalance += transation_amt;
            Utility.PrintMessage($"Depunerea de {Utility.FormatAmount(transation_amt)} a fost realizata cu succes", true);

        }

        public void MakeWithdrawal()
        {
            var transaction_amt = 0;
            int selectedAmount = AppScreen.SelectAmount();
            if (selectedAmount == -1)
            {
                MakeWithdrawal();
                return;
            }
            else if(selectedAmount !=0)
            {
                transaction_amt = selectedAmount;
            }
            else
            {
                transaction_amt = Validator.Convert<int>($"suma {AppScreen.cur}");
            }

            if (transaction_amt <= 0)
            {
                Utility.PrintMessage("Suma trebuie sa fie mai mare decat 0. Incercati din nou.", false);
                return;
            }

            if(transaction_amt % 5 != 0)
            {
                Utility.PrintMessage("Puteti retrage doar multipli de 5 si 10. Incercati din nou.", false);
                return;
            }

            if(transaction_amt>selectedAccount.AccountBalance)
            {
                Utility.PrintMessage($"Retragere esuata. Soldul dumneavoastra e prea scazut pentru a retrage {Utility.FormatAmount(transaction_amt)}", false);
                return;
            }
            if((selectedAccount.AccountBalance - transaction_amt) < minimumKeptAmount)
            {
                Utility.PrintMessage($"Retragere esuata. Contul dumneavoastra trebuie sa aiba minim {Utility.FormatAmount(minimumKeptAmount)}", false);
                return;
            }

            InsertTransaction(selectedAccount.Id, TransactionType.Withdrawal, -transaction_amt, "");
            selectedAccount.AccountBalance -= transaction_amt;
            Utility.PrintMessage($"Ati retras cu succes {Utility.FormatAmount(transaction_amt)}", true);


        }

        private bool PreviewBanknotesCount(int amount)
        {
            int tenNotesCount = amount / 10;
            int fiveNotesCount = (amount % 10) / 5;

            Console.WriteLine("\nConspect");
            Console.WriteLine("-------");
            Console.WriteLine($"{AppScreen.cur}10 X {tenNotesCount}={10 * tenNotesCount}");
            Console.WriteLine($"{AppScreen.cur}5 X {fiveNotesCount}={5 * fiveNotesCount}");
            Console.WriteLine($"Suma totala: {Utility.FormatAmount(amount)}\n\n");

            int opt = Validator.Convert<int>("Scrieti 1 pentru a confirma");
            return opt.Equals(1);
        }

        public void InsertTransaction(long _UserBankAccountId, TransactionType _tranType, decimal _tranAmount, string _desc)
        {
            var transaction = new Transaction()
            {
                TransactionId = Utility.GetTransactionId(),
                UserBankAccountId = _UserBankAccountId,
                TransactionDate = DateTime.Now,
                TransactionType = _tranType,
                TransactionAmount = _tranAmount,
                Description = _desc
            };

            _listOfTransactions.Add(transaction);
        }

        public void ViewTransaction()
        {
            var filteredTransactionList = _listOfTransactions.Where(t => t.UserBankAccountId == selectedAccount.Id).ToList();
            if(filteredTransactionList.Count<=0)
            {
                Utility.PrintMessage("Nu aveti nicio tranzactie inca.",true);
            }
            else
            {
                var table = new ConsoleTable("Id", "Data Tranzactiei", "Tipul", "Descriere", "Suma " + AppScreen.cur);
                foreach(var tran in filteredTransactionList)
                {
                    table.AddRow(tran.TransactionId, tran.TransactionDate, tran.TransactionType, tran.Description, tran.TransactionAmount);
                }

                table.Options.EnableCount = false;
                table.Write();
                Utility.PrintMessage($"Aveti {filteredTransactionList.Count} tranzactii", true);

            }
        }

        private void ProcessInternalTransfer(InternalTransfer internalTransfer)
        {
            if(internalTransfer.TransferAmount<=0)
            {
                Utility.PrintMessage("Suma trebuie sa fie mai mare decat 0. Incercati din nou.", false);
                return;
            }

            if (internalTransfer.TransferAmount > selectedAccount.AccountBalance)
            {
                Utility.PrintMessage($"Transfer esuat. Soldul nu este suficient de mare pentru a transfera {Utility.FormatAmount(internalTransfer.TransferAmount)}", false);
                return;
            }

            if ((selectedAccount.AccountBalance - internalTransfer.TransferAmount) < minimumKeptAmount)
            {
                Utility.PrintMessage($"Transfer esuat. Contul dumneavoastra trebuie sa aiba minim {Utility.FormatAmount(minimumKeptAmount)}", false);
                return;
            }

            var selectedBankAccountReciever = (from userAcc in userAccountList
                                               where userAcc.AccountNumber == internalTransfer.RecipientBankAccountNumber
                                               select userAcc).FirstOrDefault();
            if (selectedBankAccountReciever == null)
            {
                Utility.PrintMessage("Transfer esuat. Numarul contului destinatarului este invalid", false);
                return;
            }

            if(selectedBankAccountReciever.FullName != internalTransfer.RecipientBankAccountName)
            {
                Utility.PrintMessage("Transfer esuat. Numele destinatarului este invalid", false);
                return;
            }

            InsertTransaction(selectedAccount.Id, TransactionType.Transfer, -internalTransfer.TransferAmount,$"Transferat lui {selectedBankAccountReciever.AccountNumber} ({selectedBankAccountReciever.FullName})");
            selectedAccount.AccountBalance -= internalTransfer.TransferAmount;

            InsertTransaction(selectedBankAccountReciever.Id, TransactionType.Transfer, internalTransfer.TransferAmount, $"Transferat de la {selectedAccount.AccountNumber}({selectedAccount.FullName})");

            selectedBankAccountReciever.AccountBalance += internalTransfer.TransferAmount;

            Utility.PrintMessage($"Ati transferat {Utility.FormatAmount(internalTransfer.TransferAmount)} lui {internalTransfer.RecipientBankAccountName} cu succes", true);
        }
    }
}
